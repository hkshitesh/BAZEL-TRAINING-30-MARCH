from shared.config import MESSAGE
import ctypes
import os


def main():
    print(MESSAGE)
    print("Polyglot build example (Python + C++)")

    dll_path = os.path.join(os.path.dirname(__file__), "..", "cpp", "math_shared.dll")

    lib = ctypes.CDLL(dll_path)
    print(lib.add(2, 3))


if __name__ == "__main__":
    main()