#ifndef MATH_H
#define MATH_H

#ifdef _WIN32
    #define EXPORT __declspec(dllexport)
#else
    #define EXPORT
#endif

extern "C" EXPORT int add(int a, int b);

#endif
