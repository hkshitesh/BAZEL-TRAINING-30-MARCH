#include "math.h"

extern "C" EXPORT int add(int a, int b) {
    return a + b;
}
