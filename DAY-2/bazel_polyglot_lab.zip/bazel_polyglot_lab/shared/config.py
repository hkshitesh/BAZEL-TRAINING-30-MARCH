MESSAGE = "Hello from shared config"
