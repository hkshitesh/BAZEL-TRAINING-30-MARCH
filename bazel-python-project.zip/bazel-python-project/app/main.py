from mathlib.operations import add
from utils.logger import log

result = add(5, 3)
log(f"Result is {result}")
