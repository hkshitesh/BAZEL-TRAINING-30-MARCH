def _uppercase_impl(ctx):
    input_file = ctx.file.src
    output_file = ctx.actions.declare_file(ctx.label.name + ".txt")

    ctx.actions.run_shell(
        inputs = [input_file],
        outputs = [output_file],
        command = "cat {} | tr 'a-z' 'A-Z' > {}".format(
            input_file.path,
            output_file.path,
        ),
    )

    return DefaultInfo(files = depset([output_file]))

uppercase_rule = rule(
    implementation = _uppercase_impl,
    attrs = {
        "src": attr.label(allow_single_file = True),
    },
)
