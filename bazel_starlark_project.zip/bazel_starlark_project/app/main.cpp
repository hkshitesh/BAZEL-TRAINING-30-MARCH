#include <iostream>
#include <fstream>
#include <string>

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cout << "No input file provided\n";
        return 1;
    }

    std::ifstream file(argv[1]);
    std::string line;

    if (file.is_open()) {
        std::cout << "Processed Output:\n";
        while (getline(file, line)) {
            std::cout << line << std::endl;
        }
    } else {
        std::cout << "Unable to open file: " << argv[1] << std::endl;
    }

    return 0;
}
